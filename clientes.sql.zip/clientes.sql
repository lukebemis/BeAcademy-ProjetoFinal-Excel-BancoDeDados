-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 14-Dez-2022 às 13:48
-- Versão do servidor: 8.0.31
-- versão do PHP: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `fzth`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `idCliente` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT 'Primary Key vai ser varchar, 5 caracteres, um cliente pode ter mais de um plano no seu cpf, por isso não o cpf primary',
  `Nome` text NOT NULL COMMENT 'Nome do Cliente',
  `CPF` varchar(11) NOT NULL COMMENT 'CPF do cliente',
  `Telefone` varchar(11) NOT NULL COMMENT 'Telefone',
  `E-mail` varchar(32) NOT NULL COMMENT 'campo de email',
  `Data Nascimento` date NOT NULL,
  `CEP` varchar(8) NOT NULL,
  `Cidade` varchar(60) NOT NULL COMMENT '60 caracteres caso seja nome muito grande',
  `UF` varchar(2) NOT NULL COMMENT 'Estado',
  `Plano Atual` varchar(30) NOT NULL COMMENT 'varchar caso algum plano use números futuramente',
  `Duração` varchar(2) NOT NULL,
  `Data Adesão` date NOT NULL,
  `Data Término` date NOT NULL,
  PRIMARY KEY (`idCliente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COMMENT='Tabela de Clientes FZTH';

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`idCliente`, `Nome`, `CPF`, `Telefone`, `E-mail`, `Data Nascimento`, `CEP`, `Cidade`, `UF`, `Plano Atual`, `Duração`, `Data Adesão`, `Data Término`) VALUES
('TXtjd', 'Júlio Luiz Mendonça Texeira', '43728829129', '61996758365', 'julio.texeira@geradornv.com.br', '2001-12-13', '72316-52', 'Brasília', 'DF', 'GRÁTIS', '0', '2021-01-25', '2021-01-25'),
('9YeNK', 'Luciana Corrêa Castro', '80466861907', '45969173343', 'luciana.castro@geradornv.com.br', '1994-03-05', '87206-35', 'Cianorte', 'PR', 'DEV SEMESTRAL', '6', '2022-05-04', '2022-11-04'),
('97GVf', 'Ryan Claudino Siqueira', '65774260402', '81968766827', 'ryan.siqueira@geradornv.com.br', '1986-01-02', '53090-36', 'Olinda', 'PE', 'DEV TRIMESTRAL', '3', '2022-04-16', '2022-07-16'),
('5elfz', 'Deivison Werling Espindola\r\n', '22111838403', '82973515567', 'deivison.espindola@geradornv.com', '1989-06-10', '57311-22', 'Arapiraca', 'AL', 'DEV TRIMESTRAL', '3', '2022-01-24', '2022-04-24'),
('TODTb', 'Luan Vaz Nunes', '80986426156', '66999571268', 'luan.nunes@geradornv.com.br', '0000-00-00', '78152-30', 'Várzea Grande', 'MT', 'GRÁTIS', '0', '2021-01-03', '2021-01-03'),
('1AHI4', 'Tobias Meyer Brito', '24914446740', '22983422334', 'tobias.brito@geradornv.com.br', '1988-08-07', '28026-10', 'Campos dos Goytacazes', 'RJ', 'GRÁTIS', '0', '2021-04-24', '2021-04-24'),
('Xf3tW', 'Thalia Braga Filho\r\n', '41256237248', '96994495716', 'thalia.filho@geradornv.com.br', '2003-04-19', '68903-74', 'Macapá', 'AP', 'DEV SEMESTRAL', '6', '2022-02-08', '2022-06-08'),
('l4x9u', 'Nelmo Paes Queiroz', '17987264407', '84973171507', 'nelmo.queiroz@geradornv.com.br', '1974-07-04', '59143-20', 'Parnamirim', 'RN', 'DEV TRIMESTRAL', '3', '2021-05-29', '2021-08-29'),
('PUONj', 'Levi Darmont Milanez', '11399762575', '77993698575', 'levi.milanez@geradornv.com.br', '1986-10-30', '40711-09', 'Salvador', 'BA', 'GRÁTIS', '0', '2022-02-05', '2022-02-05'),
('P25Es', 'Luis Abreu Garcia', '48557478232', '95973627241', 'luis.garcia@geradornv.com.br', '1996-06-14', '69306-35', 'Boa Vista', 'RR', 'GRÁTIS', '0', '2021-09-08', '2021-09-08'),
('10iq9', 'Hilton Bocafoli Farinha\r\n', '13347289170', '61985298878', 'hilton.farinha@geradornv.com.br', '1982-11-13', '70722-50', 'Brasília', 'DF', 'DEV ANUAL', '12', '2021-04-27', '2022-04-27'),
('wlfrb', 'Adso Bonimo Grilo', '52671687850', '11971894418', 'adso.grilo@geradornv.com.br', '1977-04-18', '05281-17', 'São Paulo', 'SP', 'DEV SEMESTRAL', '6', '2021-09-07', '2022-03-07'),
('TmlOI', 'Domingos Lessa Esteves\r\n', '12090114410', '83992768371', 'domingos.esteves@geradornv.com.b', '2000-05-07', 'João Pes', 'João Pessoa\n', 'PB', 'DEV TRIMESTRAL', '3', '2022-04-24', '2022-07-24'),
('eyIYL', 'Valmir Salomão Carvalheiro', '38402354211', '92982457725', 'valmir.carvalheiro@geradornv.com', '1987-05-16', '69059-61', 'Manaus', 'AM', 'GRÁTIS', '0', '2021-06-12', '2021-06-12'),
('qmMyW', 'Roberto de Arruda Muchão\r\n', '66179628696', '35984793270', 'roberto.muchao@geradornv.com.br', '1965-09-05', '35501-49', 'Divinópolis', 'MG', 'DEV PRO', '12', '2022-03-22', '2023-03-22'),
('LDPdt', 'Miguel Gomes Fernando\r\n', '59658636594', '75975781681', 'miguel.fernando@geradornv.com.br', '1988-05-26', '40315-57', 'Salvador', 'BA', 'GRÁTIS', '0', '2021-04-20', '2021-04-20'),
('p93wg', 'Jean Guimarães Quintela\r\n', '45826820730', '28984881715', 'jean.quintela@geradornv.com.br', '1985-03-05', '29010-02', 'Vitória', 'ES', 'DEV TRIMESTRAL', '3', '2021-01-12', '2021-04-12'),
('T3gBO', 'Sebastião Caldas Carino\r\n', '83155220350', '89988640785', 'sebastiao.carino@geradornv.com.b', '1995-04-16', '64605-42', 'Picos', 'PI', 'DEV SEMESTRAL', '6', '2021-07-11', '2022-01-11'),
('jzgPA', 'Andrey Frotté Trindade\r\n', '08620056204', '69987631647', 'andrey.trindade@geradornv.com.br', '1999-04-24', '76876-67', 'Ariquemes', 'RO', 'EMPRESARIAL', '12', '2022-02-03', '2023-02-03'),
('G9I7z', 'Michel Abreu Mayerhofer\r\n', '92253946320', '99983717624', 'michel.mayerhofer@geradornv.com.', '1992-06-11', '65635-32', 'Timon', 'MA', 'GRÁTIS', '0', '2021-08-07', '2021-08-07'),
('jZCNI', 'Dionísio Lima Nigro\r\n', '28540682540', '79969311417', 'dionisio.nigro@geradornv.com.br', '1991-11-11', '49092-64', 'Aracaju', 'SE', 'DEV SEMESTRAL', '6', '2021-06-24', '2021-12-24'),
('foMqi', 'Piter Spilman Garcia\r\n', '14688387920', '47967938681', 'piter.garcia@geradornv.com.br', '1982-07-19', '89809-88', 'Chapecó', 'SC', 'DEV TRIMESTRAL', '3', '2022-03-05', '2022-06-05'),
('YRLxc', 'Márcio Biango Teixeira\r\n', '85853587005', '51967207543', 'marcio.teixeira@geradornv.com.br', '1994-02-22', '93804-54', 'Sapiranga', 'RS', 'DEV SEMESTRAL', '6', '2021-09-25', '2022-03-25'),
('nOZUs', 'Elias Passos Barellos\r\n', '78457468006', '15326584727', 'elias.barellos@geradornv.com.br', '2004-04-18', '93020-13', 'São Leopoldo', 'RS', 'DEV ANUAL', '12', '2022-07-20', '2023-07-20'),
('hpxdJ', 'Iago Caldas Paes\r\n', '19877463415', '84973888967', 'iago.paes@geradornv.com.br', '1973-09-09', '59092-51', 'Natal', 'RN', 'GRÁTIS', '0', '2021-06-21', '2021-06-21'),
('Diizt', 'Kaique Cruz Baesso\r\n', '12663431214', '95996727861', 'kaique.baesso@geradornv.com.br', '1974-03-03', '69303-45', 'Boa Vista', 'RR', 'GRÁTIS', '0', '2022-03-02', '2022-03-02'),
('Puv43', 'Benjamin de Arruda\r\n', '36419055245', '94999822876', 'benjamin.arruda@geradornv.com.br', '2002-05-17', '67030-63', 'Ananindeua', 'PA', 'DEV PRO', '12', '2022-03-23', '2023-03-23'),
('eSTha', 'Gael Bon Fontes\r\n', '63930858606', '31985183846', 'gael.fontes@geradornv.com.br', '2004-05-09', '37704-64', 'Poços de Caldas', 'MG', 'DEV ANUAL', '12', '2021-09-05', '2022-09-05'),
('eiXMk', 'Yago Norte Gonçalves\r\n', '82664591185', '67993546516', 'yago.goncalves@geradornv.com.br', '1990-05-31', '79045-57', 'Campo Grande', 'MS', 'DEV TRIMESTRAL', '3', '2022-01-20', '2022-04-20'),
('h0WXa', 'Fernando Cosme Junior\r\n', '62854345142', '62986219175', 'fernando.junior@geradornv.com.br', '1983-01-15', '74684-15', 'Goiânia', 'GO', 'DEV ANUAL', '12', '2022-02-19', '2023-02-19'),
('iTU30', 'Anthony Correia Silvino\r\n', '10354546376', '85997818321', 'anthony.silvino@geradornv.com.br', '1989-03-24', '61658-02', 'Caucaia', 'CE', 'DEV SEMESTRAL', '6', '2022-01-16', '2022-07-16'),
('dKFZh', 'Thales França Giacomini\r\n', '95732311238', '96979318767', 'thales.giacomini@geradornv.com.b', '2022-08-03', '68928-15', 'Santana', 'AP', 'GRÁTIS', '0', '2021-02-17', '2021-02-17'),
('wZYOc', 'Adriano Corrêa Campelo\r\n', '36342692432', '82971743590', 'adriano.campelo@geradornv.com.br', '1973-08-15', '57040-28', 'Maceió', 'AL', 'DEV SEMESTRAL', '6', '2022-01-26', '2022-07-26'),
('Crbpk', 'Ian Valladares Felix\r\n', '46276567264', '68997559438', 'ian.felix@geradornv.com.br', '1977-09-12', '69921-19', 'Rio Branco', 'AC', 'DEV SEMESTRAL', '6', '2021-05-09', '2021-11-09');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
